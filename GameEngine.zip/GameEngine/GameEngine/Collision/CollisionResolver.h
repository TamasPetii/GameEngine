#pragma once
class CollisionResolver
{
};

