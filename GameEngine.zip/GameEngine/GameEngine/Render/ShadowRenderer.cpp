#include "ShadowRenderer.h"

void ShadowRenderer::RenderDirLightShadows()
{
}

void ShadowRenderer::RenderPointLightShadows()
{
}

void ShadowRenderer::RenderSpotLightShadows()
{
}
