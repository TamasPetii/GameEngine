#pragma once
class ForwardRenderer
{
};

