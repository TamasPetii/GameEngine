#pragma once

class ShadowRenderer
{
public:
private:
	static void RenderDirLightShadows();
	static void RenderPointLightShadows();
	static void RenderSpotLightShadows();
};

