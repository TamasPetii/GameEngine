#pragma once
#include <limits>

using Index = unsigned int;
using Entity = unsigned int;
using Parent = unsigned int;
using Child = unsigned int;
const unsigned int null = std::numeric_limits<unsigned int>::max();