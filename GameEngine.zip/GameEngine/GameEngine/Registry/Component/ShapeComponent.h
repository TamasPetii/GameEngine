#pragma once
#include <memory>
#include <glm/glm.hpp>
#include <Registry/Component/Component.h>
#include <Geometry/Geometry.h>

class ShapeComponent : public Component
{
public:
	bool toRender{ true };
	bool castShadow{ true };
	bool receiveShadow{ true };
	std::shared_ptr<Geometry> shape;
};