#include "DefaultColliderSystem.h"

void DefaultColliderSystem::OnStart(std::shared_ptr<Registry> registry, std::shared_ptr<ResourceManager> manager)
{

}

void DefaultColliderSystem::OnUpdate(std::shared_ptr<Registry> registry, std::shared_ptr<ResourceManager> manager)
{
	auto dcTransformSsbo = manager->GetSsbo("DefaultColliderTransform");
	auto dcTransformSsboHandler = static_cast<glm::mat4*>(dcTransformSsbo->MapBuffer(GL_WRITE_ONLY));
	auto defaultColliderPool = registry->GetComponentPool<DefaultCollider>();
	auto transformPool = registry->GetComponentPool<TransformComponent>();
	auto shapePool = registry->GetComponentPool<ShapeComponent>();

	std::for_each(std::execution::par, defaultColliderPool->GetDenseEntitiesArray().begin(), defaultColliderPool->GetDenseEntitiesArray().end(),
		[&](const Entity& entity) -> void {
			if (transformPool->HasComponent(entity) && 
				shapePool->HasComponent(entity) &&
				shapePool->GetComponent(entity).shape != nullptr &&
				(defaultColliderPool->IsFlagSet(entity, UPDATE_FLAG) || transformPool->IsFlagSet(entity, CHANGED_FLAG)))
			{
				auto& defaultCollderComponent = defaultColliderPool->GetComponent(entity);
				auto& transformComponent = transformPool->GetComponent(entity);
				auto& shapeComponent = shapePool->GetComponent(entity);
				auto indexDC = defaultColliderPool->GetIndex(entity);

				for (unsigned int i = 0; i < 8; ++i)
				{
					glm::vec4 point = transformComponent.fullTransform * glm::vec4(shapeComponent.shape->GetObb()[i], 1);
					defaultCollderComponent.positions[i] = glm::vec3(point);
				}

				defaultCollderComponent.origin = transformComponent.fullTransform * glm::vec4(shapeComponent.shape->GetObbOrigin(), 1);

				glm::mat4 dcTransform = transformComponent.fullTransform * glm::translate(shapeComponent.shape->GetObbOrigin()) * glm::scale(shapeComponent.shape->GetObbExtents());		
				dcTransformSsboHandler[indexDC] = dcTransform;
				defaultColliderPool->ResFlag(entity, UPDATE_FLAG);
			}
		}
	);


	dcTransformSsbo->UnMapBuffer();
}