#include "FilesystemPanel.h"

void FilesystemPanel::Update()
{

}

void FilesystemPanel::Render()
{
	if (ImGui::Begin(TITLE_FP("Filesystem")))
	{
	}

	ImGui::End();
}